package so;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/** Class control the process that will be arriving at the scheduler and its times of execution **/
public class handler{                            
    List<fullProcess> inputedL;    //List of associated processes and its resources        
    List<fullProcess> inCpu;       //List of process in cpu    
    
    /** Sets the list as the inputed for testing **/
    public handler(List<fullProcess> inputedL){
        this.inputedL = inputedL;
        this.inCpu = new ArrayList();
    }
    
    /** Starts the control system **/
    public void run(changePriority changeP){ 
        this.tryInsertProcess(changeP);
        this.tryDeleteProcess(changeP);
        this.checkEndedResource(changeP);
        process p = this.requestResource(changeP.getProcess(), changeP);    
        if(p != null){changeP.change(p);}
                
    }
    
    /** Delete process if its executed time is equals to its weight**/
    public void tryDeleteProcess(changePriority changeP){
        for(fullProcess full: inCpu){                   
            if (full.getProcess().getId() == changeP.getProcess().getId()){
                if (changeP.getProcess().getExtime() == full.getWeight()){
                    changeP.deleteProcess();
                }
            break;    
            } 
        }
    }
    
    /** Insert process if its starting time is the actual time **/
    public void tryInsertProcess(changePriority changeP){
        Iterator<fullProcess> ir = inputedL.iterator();
        while(ir.hasNext()){
            fullProcess full = ir.next();
            if (full.getArriveTime() == changeP.getTime()){
                changeP.addQueue(full.getProcess());
                inCpu.add(full);
                System.out.println("adicionando "+ full.getProcess().getId());
                ir.remove();    
            }
        }
    }
    
    /** Checks if the procsses ended using a resource **/
    public void checkEndedResource(changePriority changeP){
        fullProcess full = this.getActualFullProcess(changeP.getProcess());
        if(full == null)
            return;
        Iterator<resource> ir = full.getResource().iterator();
        while (ir.hasNext()){ 
            resource res = ir.next();
            if(res.getUsedtime() == res.getWeight()){
                Iterator<Integer> it = changeP.getProcess().getResource().iterator();
                while(it.hasNext()){
                    Integer r = it.next();
                    if(r == res.getId()){
                        it.remove();
                    }
                }
            ir.remove();
 //???           if(changeP.areResourcesDifferent(changeP.getProcess(), changeP.getChange()) == true){
   //             changeP.changeProcessP(changeP.getProcess(), changeP.getChange());
          //      }
            }
        }
    }
   
    /** Try to alocate resouces to the process **/
    public process requestResource(process proc, changePriority changeP){
        fullProcess full = this.getActualFullProcess(proc); 
        if(full == null)
            return null;
        Iterator<resource> ir = full.getResource().iterator();
        while(ir.hasNext()){
            resource res = ir.next();
                for (process p: changeP.getQueue()){
                    for(Integer r: p.getResource()){
                        if(r == res.getId()){
                            return p;
                        }
                    }
                }
            if(proc.getExtime() == res.getStart()){
                proc.addResource(res.getId());
            }
        }
        return null;
    }
    
    /** Adds executed time to resouces **/
    public void addTimeRes(process p){    
        if(p == null || inCpu.isEmpty() || p.getId() == -1)
            return;
        fullProcess full = this.getActualFullProcess(p);
        for(resource res: full.getResource()){
            for(int r: p.getResource()){
                if(res.getId() == r){    
                    res.addExeTime();
                }
            }
        }
    }
    
    /** Gets fullProcess of the process executing **/
    public fullProcess getActualFullProcess(process p){
        for (fullProcess fullOfExe: this.inCpu){
            if(fullOfExe.getProcess().getId() == p.getId()){
               return fullOfExe;
            }
        }
        return null;
    }
}