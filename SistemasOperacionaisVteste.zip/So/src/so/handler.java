package so;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/** Class control the process that will be arriving at the scheduler and its times of execution **/
public class handler{                            
    List<fullProcess> inputedL;       //List of associated processes and its resources        
    List<fullProcess> inCpu;       //List of process in cpu    
    
    /** Sets the list as the inputed for testing **/
    public handler(List<fullProcess> inputedL){
        this.inputedL = inputedL;
        this.inCpu = new ArrayList();
    }
    
    /** Starts the control system **/
    public void run(changepriority changeP){ 
        Iterator<fullProcess> ir = inputedL.iterator();
        while(ir.hasNext()){
            fullProcess testp = ir.next();
            if (testp.getArrive() == changeP.getTime()){
                inCpu.add(testp);           
                changeP.addQueue(testp.getProcess());   
                ir.remove();    
            }
           
        }
        for(fullProcess aux: inCpu){                   
            if (aux.getProcess().getId() == changeP.getProcess().getId()){
                if (changeP.getProcess().getExtime() == aux.getWeight()){
                    changeP.deleteProcess();
                }
            break;    
            } 
        }
    }
    
    /** Checks if the procsses ended using a resource **/
    public void checkEndedResource(changepriority changeP){
        for(fullProcess aux: inCpu){                      
            if (aux.getProcess().getId() == changeP.getProcess().getId()){
                Iterator<resource> ir = aux.getResource().iterator();
                while (ir.hasNext()){ 
                    resource aresour = ir.next();

            
                    if(aresour.getUsedtime() == aresour.getWeight()){
     
                        Iterator<Integer> it = changeP.getProcess().getResource().iterator();
                  
                        while(it.hasNext()){
                            Integer res = it.next();
                            if(res == aresour.getId()){
                                it.remove();
                            }
                        }
                        ir.remove();
                        if(changeP.diferentResources(changeP.getProcess(), changeP.getChange())){
                            changeP.changeP(changeP.getProcess(), changeP.getChange());
                        }
                        
                    }
                }
            break;    
            } 
        }
    }
   
    /** Try to alocate resouces to the process **/
    public void requestResource(process proc, changepriority changeP){
        fullProcess full = this.getActualFullProcess(proc); 
        if(full == null)
            return;
        Iterator<resource> ir = full.getResource().iterator();
        
        while(ir.hasNext()){
            resource aresour = ir.next();
                    for (process p: changeP.getQueue()){
                        for(Integer r: p.getResource()){
                            if(r == aresour.getId()){
                                return;
                            }
                        }
                    }
                    if(proc.getExtime() == aresour.getStart()){
                        proc.addResource(aresour.getId());
                    }
                }
    }
    
    /** Adds executed time to resouces **/
    public void addTimeRes(process p){
        
        if(p == null || inCpu.isEmpty() || p.getId() == -1)
            return;
        
        fullProcess full = this.getActualFullProcess(p);
        
        for(resource res: full.getResource()){
            for(int r: p.getResource()){
                if(res.getId() == r){    
                    res.addExeTime();
                }
            }
        }
    }
    
    /** Gets fullProcess of the process executing **/
    public fullProcess getActualFullProcess(process p){
        for (fullProcess fullOfExe: this.inCpu){
            if(fullOfExe.getProcess().getId() == p.getId()){
               return fullOfExe;
            }
        }
        return null;
    }
}