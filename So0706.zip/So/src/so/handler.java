package so;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/** Class control the process that will be arriving at the scheduler and its times of execution **/
public class handler{                            
    List<fullProcess> inputedL;    //List of associated processes and its resources        
    List<fullProcess> inCpu;       //List of process in cpu  
    changePriority changeP;
    /** Sets the list as the inputed for testing **/
    public handler(List<fullProcess> inputedL, changePriority changeP){
        this.inputedL = inputedL;
        this.inCpu = new ArrayList();
        this.changeP = changeP;
    }
    /** Starts the control system **/
    public void run(){ 
        changeP.stackLowPrio();
        this.tryInsertProcess();
        this.tryDeleteProcess();
        this.checkEndedResource();
        process p = this.requestResource(changeP.getProcess());    
        if(p != null){changeP.change(p); changeP.addProcessStack(p);changeP.prioEqualsLowest();}
    }
    public void wakeProcessForResource(){
        process waiting = changeP.removeChangedProcess();
        if (waiting == null)
            return;
        if(changeP.areResourcesDifferent(waiting, changeP.getProcess())){
            changeP.changeProcessP(waiting, changeP.getProcess());
        }else{
            changeP.addProcessStack(waiting);
        }
    }
    /** Delete process if its executed time is equals to its weight**/
    public void tryDeleteProcess(){
        Iterator<fullProcess> it = inCpu.iterator();
        while(it.hasNext()){
            fullProcess full = it.next();
            if (full.getProcess().getId() == changeP.getProcess().getId()){
                if (changeP.getProcess().getExtime() == full.getWeight()){
                    changeP.deleteProcess();
                    it.remove();
                }
            break;    
            } 
        }
    }
    /** Insert process if its starting time is the actual time **/
    public void tryInsertProcess(){
        Iterator<fullProcess> ir = inputedL.iterator();
        while(ir.hasNext()){
            fullProcess full = ir.next();
            if (full.getArriveTime() == changeP.getTime()){
                changeP.addQueue(full.getProcess());
                inCpu.add(full);
                System.out.println("adicionando "+ full.getProcess().getId());
                ir.remove();    
            }
        }
    }
    /** Checks if the procsses ended using a resource **/
    public void checkEndedResource(){
        fullProcess full = this.getActualFullProcess(changeP.getProcess());
        if(full == null)
            return;
        Iterator<resource> ir = full.getResource().iterator();
        while (ir.hasNext()){ 
            resource res = ir.next();
            if(res.getUsedtime() == res.getWeight()){
                Iterator<Integer> it = changeP.getProcess().getResource().iterator();
                while(it.hasNext()){
                    Integer r = it.next();
                    if(r == res.getId()){
                        it.remove();
                        ir.remove();
                        this.wakeProcessForResource();
                    }
                }
            ir.remove();
 //???           if(changeP.areResourcesDifferent(changeP.getProcess(), changeP.getChange()) == true){
   //             changeP.changeProcessP(changeP.getProcess(), changeP.getChange());
          //      }
            }
        }
    }
   
    /** Try to alocate resouces to the process **/
    public process requestResource(process proc){
        System.out.println("------ processo : "+proc.getId());
        fullProcess full = this.getActualFullProcess(proc); 
        if(full == null)
            return null;
        Iterator<resource> ir = full.getResource().iterator();
        
        while(ir.hasNext()){
            resource res = ir.next();
            System.out.println("+++recurso :"+res.getId());
                for (process p: changeP.getQueue()){
                    for(Integer r: p.getResource()){
                        if(r == res.getId()){
                            System.out.println("retornouuuuuuuu");
                            return p;
                        }
                    }
                }
        
            if(proc.getExtime() == res.getStart()){
                proc.addResource(res.getId());
            }
        }
        return null;
    }
    
    /** Adds executed time to resouces **/
    public void addTimeRes(process p){    
        if(p == null || inCpu.isEmpty() || p.getId() == -1)
            return;
        fullProcess full = this.getActualFullProcess(p);
        if (full == null)
            return;
        for(resource res: full.getResource()){
            for(int r: p.getResource()){
                if(res.getId() == r){    
                    res.addExeTime();
                }
            }
        }
    }
    
    /** Gets fullProcess of the process executing **/
    public fullProcess getActualFullProcess(process p){
        for (fullProcess fullOfExe: this.inCpu){
            if(fullOfExe.getProcess().getId() == p.getId()){
               return fullOfExe;
            }
        }
        return null;
    }
}